/**
 * The thirteen gifts the Crab Courier carries. Shared by the gift handlers for
 * validation and by the delivery-card text.
 */
export const GIFT_CATALOG: Record<string, string> = {
  'fish-taco': 'Fish Taco',
  seashell: 'Seashell',
  'gold-tee-time': 'Golf Tee Time',
  'jungle-juice': 'Jungle Juice',
  'complimentary-sand': 'Complimentary Sand',
  'suspicious-towel': 'Suspicious Towel',
  'mosquito-diplomacy-kit': 'Mosquito Diplomacy Kit',
  'souvenir-magnet': 'Souvenir Magnet',
  'laminated-map': 'Laminated Island Map',
  'spf-90': 'Sunscreen (SPF 90)',
  'ferry-ticket': 'Ferry Ticket (one-way)',
  'island-citizenship': 'Certificate of Island Citizenship',
  'karaoke-machine': 'Karaoke Machine (shared)',
};

/** Strips decoration and keeps only the characters an X handle can contain. */
export function sanitizeHandle(raw: unknown): string {
  if (typeof raw !== 'string') return '';
  return raw.replace(/^@+/, '').replace(/[^A-Za-z0-9_]/g, '').slice(0, 24);
}
