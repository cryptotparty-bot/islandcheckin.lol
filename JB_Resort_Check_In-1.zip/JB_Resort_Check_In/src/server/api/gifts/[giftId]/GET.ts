import type { Request, Response } from 'express';
import { eq } from 'drizzle-orm';
import { db } from '../../../db/client.js';
import { gifts } from '../../../db/schema.js';
import { GIFT_CATALOG } from '../catalog.js';

/** One delivery, addressed by its public card id. */
export default async function handler(req: Request<{ giftId: string }>, res: Response) {
  try {
    const rows = await db
      .select({
        id: gifts.publicId,
        gift: gifts.gift,
        to: gifts.toHandle,
        from: gifts.fromHandle,
        note: gifts.note,
        at: gifts.createdAt,
      })
      .from(gifts)
      .where(eq(gifts.publicId, req.params.giftId))
      .limit(1);
    const row = rows[0];
    if (!row) {
      return res.status(404).json({ error: 'No such delivery. The crab shrugs.' });
    }
    res.set('Cache-Control', 'no-store');
    res.json({ ...row, giftName: GIFT_CATALOG[row.gift] ?? row.gift });
  } catch (error) {
    res.status(500).json({ error: 'Delivery lookup failed', message: String(error) });
  }
}
