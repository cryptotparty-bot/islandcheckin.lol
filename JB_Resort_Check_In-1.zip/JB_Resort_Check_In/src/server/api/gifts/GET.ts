import type { Request, Response } from 'express';
import { desc } from 'drizzle-orm';
import { db } from '../../db/client.js';
import { gifts } from '../../db/schema.js';

/** The public delivery log, most recent deliveries first. */
export default async function handler(_req: Request, res: Response) {
  try {
    const rows = await db
      .select({
        id: gifts.publicId,
        gift: gifts.gift,
        to: gifts.toHandle,
        from: gifts.fromHandle,
        note: gifts.note,
        at: gifts.createdAt,
      })
      .from(gifts)
      .orderBy(desc(gifts.createdAt))
      .limit(50);
    res.set('Cache-Control', 'no-store');
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: 'Delivery log unavailable', message: String(error) });
  }
}
