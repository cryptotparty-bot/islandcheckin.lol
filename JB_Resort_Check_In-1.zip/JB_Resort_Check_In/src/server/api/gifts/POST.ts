import type { Request, Response } from 'express';
import { randomUUID } from 'node:crypto';
import { db } from '../../db/client.js';
import { gifts } from '../../db/schema.js';
import { GIFT_CATALOG, sanitizeHandle } from './catalog.js';

/** Issues a delivery: one gift, one recipient, optionally a sender and a note. */
export default async function handler(req: Request, res: Response) {
  try {
    const body = (req.body ?? {}) as Record<string, unknown>;
    const giftId = typeof body.gift === 'string' ? body.gift : '';
    const giftName = GIFT_CATALOG[giftId];
    const toHandle = sanitizeHandle(body.to);
    const fromHandle = sanitizeHandle(body.from);
    const note = typeof body.note === 'string' ? body.note.trim().slice(0, 200) : '';

    if (!giftName) {
      return res.status(400).json({ error: 'The crab does not carry that item.' });
    }
    if (!toHandle) {
      return res.status(400).json({ error: 'A recipient handle is required.' });
    }

    const publicId = randomUUID().replace(/-/g, '').slice(0, 10);
    await db.insert(gifts).values({
      publicId,
      gift: giftId,
      toHandle,
      fromHandle: fromHandle || null,
      note: note || null,
    });

    res.status(201).json({
      id: publicId,
      gift: giftId,
      giftName,
      to: toHandle,
      from: fromHandle || null,
      note: note || null,
    });
  } catch (error) {
    res.status(500).json({ error: 'Delivery failed', message: String(error) });
  }
}
