import type { Request, Response } from 'express';
import { sql } from 'drizzle-orm';
import { db } from '../../db/client.js';
import { checkins } from '../../db/schema.js';

/**
 * Neighborhoods in fixed assignment order, each with the rectangle of the
 * island map (in percent of image width/height) its bungalows occupy.
 */
const HOODS: Array<{ id: string; x0: number; x1: number; y0: number; y1: number }> = [
  { id: 'neon-lagoon', x0: 6, x1: 38, y0: 55, y1: 88 },
  { id: 'coconut-heights', x0: 36, x1: 64, y0: 8, y1: 38 },
  { id: 'shipwreck-shore', x0: 62, x1: 92, y0: 30, y1: 66 },
  { id: 'questionable-marina', x0: 52, x1: 90, y0: 72, y1: 92 },
];

/** FNV-1a — stable pseudorandom assignment from the handle alone. */
function hashHandle(handle: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < handle.length; i++) {
    h ^= handle.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h >>> 0;
}

export default async function handler(req: Request, res: Response) {
  try {
    const raw = typeof req.body?.handle === 'string' ? req.body.handle : '';
    const handle = raw.replace(/^@+/, '').replace(/[^A-Za-z0-9_]/g, '').slice(0, 24);
    if (!handle) {
      return res.status(400).json({ error: 'A handle is required to check in.' });
    }
    const h = hashHandle(handle);
    const hood = HOODS[h % HOODS.length];
    const x = Math.round(hood.x0 + ((h >>> 8) % 1000) / 1000 * (hood.x1 - hood.x0));
    const y = Math.round(hood.y0 + ((h >>> 19) % 1000) / 1000 * (hood.y1 - hood.y0));
    await db
      .insert(checkins)
      .values({ handle, hood: hood.id, posX: x, posY: y })
      .onDuplicateKeyUpdate({
        set: { hood: hood.id, posX: x, posY: y, createdAt: sql`CURRENT_TIMESTAMP` },
      });
    res.status(201).json({ handle, hood: hood.id, x, y });
  } catch (error) {
    res.status(500).json({ error: 'Check-in failed', message: String(error) });
  }
}
