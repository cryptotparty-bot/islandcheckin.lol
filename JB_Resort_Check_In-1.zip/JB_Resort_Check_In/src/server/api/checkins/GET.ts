import type { Request, Response } from 'express';
import { desc } from 'drizzle-orm';
import { db } from '../../db/client.js';
import { checkins } from '../../db/schema.js';

/** Public ledger of checked-in residents, newest arrival first. */
export default async function handler(_req: Request, res: Response) {
  try {
    const rows = await db
      .select({
        handle: checkins.handle,
        hood: checkins.hood,
        x: checkins.posX,
        y: checkins.posY,
        at: checkins.createdAt,
      })
      .from(checkins)
      .orderBy(desc(checkins.createdAt))
      .limit(500);
    res.set('Cache-Control', 'no-store');
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: 'Ledger unavailable', message: String(error) });
  }
}
