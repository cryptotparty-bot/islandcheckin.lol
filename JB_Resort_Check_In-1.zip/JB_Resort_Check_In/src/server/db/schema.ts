/**
 * Drizzle ORM schema entrypoint.
 *
 * Define your database tables here by exporting mysqlTable instances.
 *
 * Example:
 * export const users = mysqlTable('users', {
 *   id: int('id').primaryKey().autoincrement(),
 *   name: varchar('name', { length: 255 }).notNull(),
 *   email: varchar('email', { length: 255 }).notNull().unique(),
 *   createdAt: timestamp('created_at').defaultNow(),
 * });
 *
 * After modifying this file:
 * 1. Run: npx drizzle-kit generate
 * 2. Run: npx drizzle-kit migrate
 * 3. Call: database__listTables to verify
 */
export {};

import { int, mysqlTable, timestamp, varchar } from 'drizzle-orm/mysql-core';

/**
 * One row per resident who has checked in at the desk.
 * `hood` and the percent coordinates place their pin on the island map;
 * a repeat check-in by the same handle moves the pin (last arrival wins).
 */
export const checkins = mysqlTable('checkins', {
  id: int('id').primaryKey().autoincrement(),
  handle: varchar('handle', { length: 32 }).notNull().unique(),
  hood: varchar('hood', { length: 32 }).notNull(),
  posX: int('pos_x').notNull(),
  posY: int('pos_y').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

/**
 * One row per gift sent through the Crab Courier. publicId is the short
 * token in the shareable delivery-card URL (/gifts/:publicId).
 */
export const gifts = mysqlTable('gifts', {
  id: int('id').primaryKey().autoincrement(),
  publicId: varchar('public_id', { length: 16 }).notNull().unique(),
  gift: varchar('gift', { length: 32 }).notNull(),
  toHandle: varchar('to_handle', { length: 32 }).notNull(),
  fromHandle: varchar('from_handle', { length: 32 }),
  note: varchar('note', { length: 200 }),
  createdAt: timestamp('created_at').defaultNow(),
});
