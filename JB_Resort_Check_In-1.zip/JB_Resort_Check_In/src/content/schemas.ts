import { z } from 'zod';
export const schemas = {
  pages: {
    home: z.object({
      "aerial": z.object({
        "alt": z.string()
      }),
      "bank": z.object({
        "body": z.string(),
        "cta": z.string(),
        "label": z.string(),
        "stats": z.array(z.object({
          "id": z.string(),
          "value": z.string()
        })),
        "title": z.string(),
        "url": z.string()
      }),
      "form": z.object({
        "confirm": z.string(),
        "confirmBody": z.string(),
        "error": z.string(),
        "fieldLabel": z.string(),
        "heading": z.string(),
        "help": z.string(),
        "label": z.string(),
        "placeholder": z.string(),
        "submit": z.string(),
        "viewMap": z.string()
      }),
      "giftshop": z.object({
        "body": z.string(),
        "cta": z.string(),
        "label": z.string(),
        "stats": z.array(z.object({
          "id": z.string(),
          "value": z.string()
        })),
        "title": z.string(),
        "url": z.string()
      }),
      "hero": z.object({
        "body": z.string(),
        "eyebrow": z.string(),
        "titleItalic": z.string(),
        "titleRoman": z.string()
      }),
      "ledger": z.object({
        "claimed": z.string(),
        "latestHandle": z.string(),
        "latestJob": z.string(),
        "latestLabel": z.string(),
        "of": z.string(),
        "percent": z.number(),
        "label": z.string()
      }),
      "neighborhoods": z.object({
        "cta": z.string(),
        "label": z.string(),
        "names": z.array(z.object({
          "id": z.string(),
          "italic": z.boolean(),
          "name": z.string()
        })),
        "sub": z.string()
      }),
      "reception": z.object({
        "alt": z.string()
      }),
      "soundtrack": z.object({
        "artist": z.string(),
        "body": z.string(),
        "label": z.string(),
        "title": z.string()
      })
    }),
    map: z.object({
      "cta": z.object({
        "text": z.string(),
        "to": z.string()
      }),
      "hero": z.object({
        "body": z.string(),
        "eyebrow": z.string(),
        "title": z.string(),
        "titleItalic": z.string()
      }),
      "legend": z.object({
        "body": z.string(),
        "label": z.string()
      }),
      "pins": z.object({
        "count": z.string(),
        "empty": z.string(),
        "label": z.string(),
        "tag": z.string()
      }),
      "neighborhoods": z.array(z.object({
        "alt": z.string(),
        "id": z.string(),
        "italic": z.boolean(),
        "landmark": z.string(),
        "name": z.string(),
        "range": z.string(),
        "vibe": z.string()
      })),
      "note": z.object({
        "body": z.string(),
        "label": z.string()
      })
    }),
    registry: z.object({
      "cta": z.object({
        "text": z.string(),
        "to": z.string()
      }),
      "empty": z.object({
        "body": z.string(),
        "label": z.string()
      }),
      "hero": z.object({
        "body": z.string(),
        "eyebrow": z.string(),
        "title": z.string(),
        "titleItalic": z.string()
      }),
      "residents": z.array(z.object({
        "bungalow": z.string(),
        "handle": z.string(),
        "id": z.string(),
        "job": z.string(),
        "neighborhood": z.string(),
        "since": z.string()
      })),
      "stats": z.array(z.object({
        "id": z.string(),
        "value": z.string()
      }))
    }),
    pfp: z.object({
      "actions": z.object({
        "download": z.string(),
        "note": z.string()
      }),
      "emblems": z.array(z.object({
        "id": z.string(),
        "name": z.string()
      })),
      "hero": z.object({
        "body": z.string(),
        "eyebrow": z.string(),
        "title": z.string(),
        "titleItalic": z.string()
      }),
      "labels": z.object({
        "cameraChoose": z.string(),
        "emblem": z.string(),
        "handle": z.string(),
        "photo": z.string(),
        "photoChange": z.string(),
        "photoChoose": z.string(),
        "photoRemove": z.string(),
        "room": z.string(),
        "scene": z.string()
      }),
      "scenes": z.array(z.object({
        "id": z.string(),
        "name": z.string()
      })),
      "stats": z.array(z.object({
        "id": z.string(),
        "value": z.string()
      }))
    }),
    gifts: z.object({
      "card": z.object({
        "back": z.string(),
        "by": z.string(),
        "crab": z.string(),
        "delivered": z.string(),
        "for": z.string(),
        "from": z.string(),
        "noteLabel": z.string(),
        "notFound": z.string(),
        "notFoundLabel": z.string(),
        "open": z.string(),
        "share": z.string(),
        "title": z.string()
      }),
      "error": z.string(),
      "form": z.object({
        "fromLabel": z.string(),
        "fromPlaceholder": z.string(),
        "heading": z.string(),
        "noteLabel": z.string(),
        "noteOptional": z.string(),
        "notePlaceholder": z.string(),
        "submit": z.string(),
        "toLabel": z.string(),
        "toPlaceholder": z.string()
      }),
      "hero": z.object({
        "body": z.string(),
        "eyebrow": z.string(),
        "title": z.string(),
        "titleItalic": z.string()
      }),
      "items": z.array(z.object({
        "blurb": z.string(),
        "icon": z.string(),
        "id": z.string(),
        "name": z.string()
      })),
      "log": z.object({
        "anon": z.string(),
        "empty": z.string(),
        "heading": z.string(),
        "intro": z.string()
      }),
      "pick": z.object({
        "label": z.string()
      }),
      "success": z.object({
        "again": z.string(),
        "body": z.string(),
        "heading": z.string()
      })
    })
  }
};
export type Schemas = typeof schemas;