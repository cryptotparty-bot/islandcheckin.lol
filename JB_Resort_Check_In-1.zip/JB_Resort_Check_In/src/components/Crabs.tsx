/**
 * Decorative crabs that scuttle across the bottom of every page.
 * Pure CSS animation, pointer-events-none, hidden for reduced-motion users.
 */

interface CrabSpec {
  size: number;
  duration: number;
  delay: number;
  reverse: boolean;
  bottom: number;
}

const CRABS: CrabSpec[] = [
  { size: 40, duration: 42, delay: -6, reverse: false, bottom: 12 },
  { size: 28, duration: 64, delay: -30, reverse: true, bottom: 36 },
  { size: 52, duration: 50, delay: -20, reverse: false, bottom: 4 },
  { size: 24, duration: 78, delay: -58, reverse: true, bottom: 54 },
];

const TOP_CRABS: CrabSpec[] = [
  { size: 34, duration: 55, delay: -18, reverse: false, bottom: 30 },
  { size: 46, duration: 44, delay: -32, reverse: true, bottom: 6 },
  { size: 22, duration: 72, delay: -50, reverse: false, bottom: 52 },
];

function CrabSvg({ size, facingLeft }: { size: number; facingLeft: boolean }) {
  return (
    <svg
      width={size}
      height={Math.round(size * 0.62)}
      viewBox="0 0 100 62"
      className={facingLeft ? '-scale-x-100' : undefined}
      fill="none"
    >
      {/* legs — two alternating groups so they wiggle as it walks */}
      <g className="crab-legs-a" stroke="hsl(var(--primary))" strokeWidth="3.5" strokeLinecap="round">
        <path d="M32 42 L14 32" />
        <path d="M31 46 L10 45" />
        <path d="M32 50 L15 57" />
      </g>
      <g className="crab-legs-b" stroke="hsl(var(--primary))" strokeWidth="3.5" strokeLinecap="round">
        <path d="M68 42 L86 32" />
        <path d="M69 46 L90 45" />
        <path d="M68 50 L85 57" />
      </g>
      {/* claws */}
      <path d="M28 38 Q16 34 12 26" stroke="hsl(var(--primary))" strokeWidth="3.5" strokeLinecap="round" />
      <circle cx="11" cy="23" r="6.5" fill="hsl(var(--primary))" />
      <path d="M72 38 Q84 34 88 26" stroke="hsl(var(--primary))" strokeWidth="3.5" strokeLinecap="round" />
      <circle cx="89" cy="23" r="6.5" fill="hsl(var(--primary))" />
      {/* body */}
      <ellipse cx="50" cy="41" rx="24" ry="14" fill="hsl(var(--primary))" />
      {/* eye stalks + eyes */}
      <path d="M43 30 L39 19" stroke="hsl(var(--primary))" strokeWidth="3" strokeLinecap="round" />
      <path d="M57 30 L61 19" stroke="hsl(var(--primary))" strokeWidth="3" strokeLinecap="round" />
      <circle cx="39" cy="16" r="4" fill="hsl(var(--card))" />
      <circle cx="61" cy="16" r="4" fill="hsl(var(--card))" />
      <circle cx="40" cy="15" r="1.6" fill="hsl(var(--primary-foreground))" />
      <circle cx="62" cy="15" r="1.6" fill="hsl(var(--primary-foreground))" />
      {/* smile */}
      <path d="M43 45 Q50 50 57 45" stroke="hsl(var(--primary-foreground))" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
}

export default function Crabs({ position = 'bottom' }: { position?: 'bottom' | 'top' }) {
  const crabs = position === 'top' ? TOP_CRABS : CRABS;
  return (
    <div
      aria-hidden="true"
      className={
        'pointer-events-none fixed inset-x-0 z-30 h-24 select-none overflow-hidden ' +
        (position === 'top' ? 'top-0' : 'bottom-0')
      }
    >
      {crabs.map((crab, index) => (
        <div
          key={index}
          className="crab-track"
          style={{
            bottom: crab.bottom,
            animationDuration: crab.duration + 's',
            animationDelay: crab.delay + 's',
            animationName: crab.reverse ? 'crab-walk-reverse' : 'crab-walk',
          }}
        >
          <div className="crab-bob" style={{ animationDelay: (index * 0.17).toFixed(2) + 's' }}>
            <CrabSvg size={crab.size} facingLeft={crab.reverse} />
          </div>
        </div>
      ))}
    </div>
  );
}
