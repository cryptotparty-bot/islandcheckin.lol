import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router';
import { registry } from 'virtual:content';

const site = 'https://islandcheckin.lol';

const title = 'Island Residents — Occupants Ledger | JB Resort Check-In';
const description = 'The occupants ledger of JB Resort, a virtual island resort for Jungle Bay: island residents, their bungalows, and job titles issued once and never again.';
const url = site + '/residents';

const jsonLd = {
  '@context': 'https://schema.org',
  '@type': 'WebPage',
  '@id': url + '#webpage',
  name: 'Island Residents — Occupants Ledger',
  url,
  isPartOf: { '@id': site + '/#website' },
  about: { '@id': site + '/#organization' },
};

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: 'easeOut' as const } },
} as const;

export default function RegistryPage() {
  return (
    <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={url} />
        <meta property="og:image" content={site + '/airo-assets/images/pages/home/fairy-background'} />
        <meta property="og:image:alt" content="The JB Resort fairy queen under island moonlight" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={title} />
        <meta name="twitter:description" content={description} />
        <meta name="twitter:image" content={site + '/airo-assets/images/pages/home/fairy-background'} />
        <meta name="twitter:image:alt" content="The JB Resort fairy queen under island moonlight" />
        <script type="application/ld+json">{JSON.stringify(jsonLd).replace(/</g, '\u003c')}</script>
      </Helmet>

      <main>
        {/* Hero */}
        <section className="px-base pb-xl pt-32 sm:pt-40">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUp}
            className="mx-auto w-full max-w-content"
          >
            <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-primary">{registry.hero.eyebrow}</p>
            <h1 className="mt-lg font-heading text-5xl font-light leading-[1.05] tracking-tight text-foreground sm:text-6xl lg:text-7xl">
              {registry.hero.title} <span className="italic">{registry.hero.titleItalic}</span>
            </h1>
            <p className="mt-lg max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">{registry.hero.body}</p>
          </motion.div>
        </section>

        {/* Ledger stats */}
        <section className="px-base pb-xl">
          <div className="mx-auto w-full max-w-content">
            <ul className="flex flex-wrap gap-sm" aria-label="Occupants at a glance">
              {registry.stats.map((stat) => (
                <li key={stat.id}>
                  <span className="inline-block rounded-full border border-border bg-card/50 px-base py-1.5 font-mono text-xs text-foreground backdrop-blur-sm">
                    {stat.value}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </section>

        {/* The registry itself */}
        <section className="px-base pb-xl">
          <div className="mx-auto w-full max-w-content">
            <div className="rounded-3xl border border-border bg-card/50 p-lg backdrop-blur-sm sm:p-xl">
              <div className="hidden grid-cols-[1.2fr_1fr_2fr_auto] gap-base border-b border-border pb-base font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground lg:grid">
                <span>Handle</span>
                <span>Bungalow</span>
                <span>Job title, issued once</span>
                <span className="text-right">Status</span>
              </div>
              {registry.residents.map((resident) => (
                <div
                  key={resident.id}
                  className="grid gap-sm border-b border-border py-lg transition-colors last:border-b-0 hover:bg-accent/30 lg:grid-cols-[1.2fr_1fr_2fr_auto] lg:items-baseline lg:gap-base"
                >
                  <a
                    href={'https://x.com/' + resident.handle.replace(/^@+/, '')}
                    target="_blank"
                    rel="noreferrer"
                    className="w-fit font-mono text-sm text-primary underline-offset-4 transition-colors hover:underline focus-visible:outline-2 focus-visible:outline-ring"
                    aria-label={resident.handle + ' on X, opens in a new tab'}
                  >
                    {resident.handle}
                  </a>
                  <span className="font-mono text-xs text-foreground">
                    {resident.bungalow}
                    <span className="block text-muted-foreground lg:hidden">{resident.neighborhood}</span>
                  </span>
                  <span className="font-heading text-lg font-light italic text-muted-foreground">{resident.job}</span>
                  <span className="font-mono text-[11px] uppercase tracking-[0.15em] text-muted-foreground lg:text-right">
                    {resident.since}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* The empty lines */}
        <section className="px-base pb-xl">
          <div className="mx-auto w-full max-w-content">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeUp}
              className="rounded-3xl border border-dashed border-primary/30 bg-primary/5 p-lg sm:p-xl"
            >
              <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-primary">{registry.empty.label}</p>
              <p className="mt-base max-w-2xl text-lg leading-relaxed text-foreground">{registry.empty.body}</p>
            </motion.div>
          </div>
        </section>

        {/* CTA */}
        <section className="px-base pb-xxl">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUp}
            className="mx-auto flex w-full max-w-content justify-center"
          >
            <Link
              to="/"
              className="group inline-flex items-center gap-3 rounded-full bg-primary px-xxl py-lg font-mono text-sm uppercase tracking-[0.2em] text-primary-foreground shadow-lg transition-transform duration-200 hover:scale-[1.03] focus-visible:outline-2 focus-visible:outline-ring"
            >
              {registry.cta.text}
              <ArrowRight aria-hidden="true" className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
            </Link>
          </motion.div>
        </section>
      </main>
    </>
  );
}
