import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import { ArrowRight, Award, Bug, CupSoda, Fish, Flag, Layers, Magnet, Map, Mic, Mountain, Shell, Sun, Ticket } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import type { LucideIcon } from 'lucide-react';
import { gifts } from 'virtual:content';

const site = 'https://islandcheckin.lol';

const ICONS: Record<string, LucideIcon> = {
  fish: Fish,
  shell: Shell,
  flag: Flag,
  cup: CupSoda,
  mountain: Mountain,
  layers: Layers,
  bug: Bug,
  magnet: Magnet,
  map: Map,
  sun: Sun,
  ticket: Ticket,
  award: Award,
  mic: Mic,
};

const title = 'The Crab Courier — Island Gifts by Crab | JB Resort';
const description = 'Send one of thirteen island gifts — fish tacos, suspicious towels, karaoke machines — to any island resident. Delivered by crab, shareable on X.';
const url = site + '/gifts';

const jsonLd = {
  '@context': 'https://schema.org',
  '@type': 'WebPage',
  '@id': url + '#webpage',
  name: 'The Crab Courier',
  url,
  isPartOf: { '@id': site + '/#website' },
  about: { '@id': site + '/#organization' },
};

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: 'easeOut' as const } },
} as const;

interface Delivery {
  id: string;
  gift: string;
  to: string;
  from: string | null;
  note: string | null;
  at: string;
}

interface SentGift {
  id: string;
  gift: string;
  giftName: string;
  to: string;
  from: string | null;
  note: string | null;
}

function giftName(id: string): string {
  const item = gifts.items.find((entry) => entry.id === id);
  return item ? item.name : id;
}

export default function GiftsPage() {
  const [selected, setSelected] = useState(gifts.items[0]?.id ?? '');
  const [to, setTo] = useState('');
  const [from, setFrom] = useState('');
  const [note, setNote] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [failed, setFailed] = useState(false);
  const [sent, setSent] = useState<SentGift | null>(null);
  const [log, setLog] = useState<Delivery[] | null>(null);

  useEffect(() => {
    let cancelled = false;
    fetch('/api/gifts')
      .then((res) => (res.ok ? res.json() : []))
      .then((rows: Delivery[]) => {
        if (!cancelled) setLog(Array.isArray(rows) ? rows : []);
      })
      .catch(() => {
        if (!cancelled) setLog([]);
      });
    return () => {
      cancelled = true;
    };
  }, [sent]);

  const onSend = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (submitting) return;
    setSubmitting(true);
    setFailed(false);
    try {
      const res = await fetch('/api/gifts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gift: selected, to, from, note }),
      });
      if (!res.ok) throw new Error('dispatch refused');
      setSent((await res.json()) as SentGift);
    } catch {
      setFailed(true);
    } finally {
      setSubmitting(false);
    }
  };

  const shareUrl = sent
    ? 'https://twitter.com/intent/tweet?text=' +
      encodeURIComponent('OFFICIAL NOTICE: one (1) ' + sent.giftName + ', delivered by crab to @' + sent.to + ' at JB Resort.') +
      '&url=' +
      encodeURIComponent(site + '/gifts/' + sent.id)
    : '';

  return (
    <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={url} />
        <meta property="og:image" content={site + '/airo-assets/images/pages/home/fairy-background'} />
        <meta property="og:image:alt" content="The JB Resort fairy queen under island moonlight" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={title} />
        <meta name="twitter:description" content={description} />
        <meta name="twitter:image" content={site + '/airo-assets/images/pages/home/fairy-background'} />
        <meta name="twitter:image:alt" content="The JB Resort fairy queen under island moonlight" />
        <script type="application/ld+json">{JSON.stringify(jsonLd).replace(/</g, '\u003c')}</script>
      </Helmet>

      <main>
        {/* Hero */}
        <section className="px-base pb-xl pt-32 sm:pt-40">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mx-auto w-full max-w-content">
            <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-primary">{gifts.hero.eyebrow}</p>
            <h1 className="mt-lg font-heading text-5xl font-light leading-[1.05] tracking-tight text-foreground sm:text-6xl lg:text-7xl">
              {gifts.hero.title} <span className="italic">{gifts.hero.titleItalic}</span>
            </h1>
            <p className="mt-lg max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">{gifts.hero.body}</p>
          </motion.div>
        </section>

        {/* Gift picker + form */}
        <section className="px-base pb-xl">
          <div className="mx-auto grid w-full max-w-content gap-xl lg:grid-cols-[1fr_1fr] lg:gap-xxl">
            {/* Picker */}
            <div>
              <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-primary">{gifts.pick.label}</p>
              <div role="group" aria-label="Choose a gift" className="mt-lg grid gap-base sm:grid-cols-2">
                {gifts.items.map((item) => {
                  const Icon = ICONS[item.icon] ?? Fish;
                  const active = selected === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      aria-pressed={active}
                      onClick={() => setSelected(item.id)}
                      className={
                        'flex flex-col gap-base rounded-3xl border p-lg text-left backdrop-blur-sm transition-colors focus-visible:outline-2 focus-visible:outline-ring ' +
                        (active
                          ? 'border-primary bg-primary/10 shadow-lg'
                          : 'border-border bg-card/50 hover:border-primary/40')
                      }
                    >
                      <span className={'flex h-10 w-10 items-center justify-center rounded-full border ' + (active ? 'border-primary/60 bg-primary/15 text-primary' : 'border-border bg-accent/40 text-muted-foreground')}>
                        <Icon aria-hidden="true" className="h-5 w-5" />
                      </span>
                      <span className="font-heading text-xl font-light text-foreground">{item.name}</span>
                      <span className="text-sm leading-relaxed text-muted-foreground">{item.blurb}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Form / success */}
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="h-fit rounded-3xl border border-border bg-card/70 p-lg shadow-xl backdrop-blur-xl sm:p-xl">
              {sent ? (
                <div>
                  <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-primary">{gifts.success.heading}</p>
                  <p className="mt-base font-heading text-3xl font-light italic text-foreground">
                    1x {sent.giftName} &rarr; @{sent.to}
                  </p>
                  <p className="mt-base text-base leading-relaxed text-muted-foreground">{gifts.success.body}</p>
                  <div className="mt-lg flex flex-col gap-sm sm:flex-row">
                    <a
                      href={shareUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-xl bg-primary px-base font-mono text-sm font-medium uppercase tracking-[0.15em] text-primary-foreground transition-transform hover:scale-[1.01] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/60"
                    >
                      {gifts.card.share}
                      <ArrowRight aria-hidden="true" className="h-4 w-4" />
                    </a>
                    <Link
                      to={'/gifts/' + sent.id}
                      className="inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-xl border border-primary/60 bg-primary/10 px-base font-mono text-xs uppercase tracking-[0.15em] text-foreground transition-colors hover:border-primary hover:text-primary"
                    >
                      {gifts.card.open}
                    </Link>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setSent(null);
                      setTo('');
                      setFrom('');
                      setNote('');
                    }}
                    className="mt-lg font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground transition-colors hover:text-primary"
                  >
                    {gifts.success.again}
                  </button>
                </div>
              ) : (
                <form onSubmit={onSend}>
                  <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-primary">{gifts.form.heading}</p>
                  <label htmlFor="gift-to" className="mt-lg block font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                    {gifts.form.toLabel}
                  </label>
                  <div className="relative mt-sm">
                    <span aria-hidden="true" className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 font-mono text-muted-foreground">@</span>
                    <input
                      id="gift-to"
                      type="text"
                      value={to}
                      onChange={(e) => setTo(e.target.value)}
                      autoComplete="off"
                      autoCapitalize="none"
                      spellCheck={false}
                      placeholder={gifts.form.toPlaceholder}
                      className="h-12 w-full rounded-xl border border-input bg-background/60 pl-9 pr-4 text-foreground transition-colors placeholder:text-muted-foreground/50 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/40"
                    />
                  </div>
                  <label htmlFor="gift-from" className="mt-lg block font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                    {gifts.form.fromLabel}
                  </label>
                  <div className="relative mt-sm">
                    <span aria-hidden="true" className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 font-mono text-muted-foreground">@</span>
                    <input
                      id="gift-from"
                      type="text"
                      value={from}
                      onChange={(e) => setFrom(e.target.value)}
                      autoComplete="off"
                      autoCapitalize="none"
                      spellCheck={false}
                      placeholder={gifts.form.fromPlaceholder}
                      className="h-12 w-full rounded-xl border border-input bg-background/60 pl-9 pr-4 text-foreground transition-colors placeholder:text-muted-foreground/50 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/40"
                    />
                  </div>
                  <label htmlFor="gift-note" className="mt-lg block font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                    {gifts.form.noteLabel}
                    <span className="ml-2 normal-case tracking-normal text-muted-foreground/70">{gifts.form.noteOptional}</span>
                  </label>
                  <textarea
                    id="gift-note"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    maxLength={200}
                    rows={3}
                    placeholder={gifts.form.notePlaceholder}
                    className="mt-sm w-full resize-none rounded-xl border border-input bg-background/60 px-4 py-3 text-foreground transition-colors placeholder:text-muted-foreground/50 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/40"
                  />
                  {failed ? <p className="mt-sm font-mono text-xs text-destructive">{gifts.error}</p> : null}
                  <button
                    type="submit"
                    disabled={submitting}
                    className="mt-lg flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary font-mono text-sm font-medium uppercase tracking-[0.15em] text-primary-foreground transition-transform hover:scale-[1.01] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/60 disabled:opacity-60"
                  >
                    {submitting ? '…' : gifts.form.submit}
                    <ArrowRight aria-hidden="true" className="h-4 w-4" />
                  </button>
                </form>
              )}
            </motion.div>
          </div>
        </section>

        {/* Delivery log */}
        <section className="border-t border-border bg-card/40 px-base py-xxl">
          <div className="mx-auto w-full max-w-content">
            <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-primary">{gifts.log.heading}</p>
            <p className="mt-base max-w-xl text-lg text-muted-foreground">{gifts.log.intro}</p>
            {log !== null && log.length === 0 ? (
              <p className="mt-xl rounded-3xl border border-dashed border-primary/30 bg-primary/5 p-lg font-heading text-lg font-light italic text-foreground">
                {gifts.log.empty}
              </p>
            ) : null}
            {log !== null && log.length > 0 ? (
              <ul className="mt-xl">
                {log.map((entry) => (
                  <li key={entry.id} className="border-b border-border py-lg transition-colors last:border-b-0 hover:bg-accent/30">
                    <div className="flex flex-col gap-1 sm:flex-row sm:items-baseline sm:justify-between">
                      <span className="font-mono text-sm text-foreground">
                        1x {giftName(entry.gift)}
                        <span aria-hidden="true"> &rarr; </span>
                        <a
                          href={'https://x.com/' + entry.to}
                          target="_blank"
                          rel="noreferrer"
                          className="text-primary underline-offset-4 hover:underline"
                          aria-label={'@' + entry.to + ' on X, opens in a new tab'}
                        >
                          @{entry.to}
                        </a>
                      </span>
                      <span className="font-mono text-xs text-muted-foreground">
                        from {entry.from ? '@' + entry.from : gifts.log.anon}
                      </span>
                    </div>
                    {entry.note ? <p className="mt-1 font-heading text-base font-light italic text-muted-foreground">&ldquo;{entry.note}&rdquo;</p> : null}
                  </li>
                ))}
              </ul>
            ) : null}
          </div>
        </section>
      </main>
    </>
  );
}
