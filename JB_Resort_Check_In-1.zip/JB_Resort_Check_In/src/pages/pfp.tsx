import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import { Download } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { cn } from '@/lib/utils';
import { pfp } from 'virtual:content';

const site = 'https://islandcheckin.lol';

const title = 'PFP Foundry — Island PFP Generator | JB Resort Check-In';
const description = 'Generate a free island resident PFP for Jungle Bay: pick a scene and emblem, add your handle, download a circular 512×512 portrait. Rendered in your browser.';
const url = site + '/pfp';

const jsonLd = {
  '@context': 'https://schema.org',
  '@type': 'WebPage',
  '@id': url + '#webpage',
  name: 'PFP Foundry',
  url,
  isPartOf: { '@id': site + '/#website' },
  about: { '@id': site + '/#organization' },
};

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: 'easeOut' as const } },
} as const;

type Palette = { bgTop: string; bgBottom: string; glow: string; ink: string };

function paletteFor(scene: string): Palette {
  const styles = getComputedStyle(document.documentElement);
  const raw = (name: string) => styles.getPropertyValue(name).trim();
  const base = { ink: 'hsl(' + raw('--foreground') + ')' };
  if (scene === 'dusk') {
    return { bgTop: 'hsl(' + raw('--background') + ')', bgBottom: 'hsl(' + raw('--accent') + ')', glow: 'hsl(' + raw('--warning') + ')', ...base };
  }
  if (scene === 'daybreak') {
    return { bgTop: 'hsl(' + raw('--secondary') + ')', bgBottom: 'hsl(' + raw('--success') + ')', glow: 'hsl(' + raw('--primary') + ')', ...base };
  }
  return { bgTop: 'hsl(' + raw('--background') + ')', bgBottom: 'hsl(' + raw('--card') + ')', glow: 'hsl(' + raw('--primary') + ')', ...base };
}

function drawEmblem(ctx: CanvasRenderingContext2D, emblem: string, cx: number, cy: number, r: number, ink: string) {
  ctx.save();
  ctx.strokeStyle = ink;
  ctx.fillStyle = ink;
  ctx.lineWidth = r * 0.14;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  if (emblem === 'moon') {
    ctx.beginPath();
    ctx.arc(cx, cy, r, Math.PI * 0.35, Math.PI * 1.75);
    ctx.arc(cx - r * 0.45, cy, r * 0.72, Math.PI * 1.6, Math.PI * 0.5, true);
    ctx.closePath();
    ctx.fill();
  } else if (emblem === 'wave') {
    for (let row = 0; row < 3; row++) {
      const y = cy - r + row * r * 0.8;
      ctx.beginPath();
      ctx.moveTo(cx - r, y);
      ctx.quadraticCurveTo(cx - r * 0.5, y - r * 0.5, cx, y);
      ctx.quadraticCurveTo(cx + r * 0.5, y + r * 0.5, cx + r, y);
      ctx.stroke();
    }
  } else if (emblem === 'star') {
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
      const radius = i % 2 === 0 ? r : r * 0.45;
      const angle = (Math.PI / 5) * i - Math.PI / 2;
      const x = cx + radius * Math.cos(angle);
      const y = cy + radius * Math.sin(angle);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fill();
  } else if (emblem === 'shell') {
    ctx.beginPath();
    ctx.arc(cx, cy + r * 0.7, r * 0.25, 0, Math.PI, true);
    ctx.fill();
    for (let i = -2; i <= 2; i++) {
      ctx.beginPath();
      ctx.moveTo(cx, cy + r * 0.7);
      ctx.quadraticCurveTo(cx + i * r * 0.55, cy - r * 0.4, cx + i * r * 0.7, cy - r * 0.75 + Math.abs(i) * r * 0.35);
      ctx.stroke();
    }
  } else if (emblem === 'anchor') {
    ctx.beginPath();
    ctx.arc(cx, cy - r * 0.8, r * 0.22, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx, cy - r * 0.55);
    ctx.lineTo(cx, cy + r * 0.9);
    ctx.moveTo(cx - r * 0.45, cy - r * 0.1);
    ctx.lineTo(cx + r * 0.45, cy - r * 0.1);
    ctx.moveTo(cx - r * 0.75, cy + r * 0.35);
    ctx.quadraticCurveTo(cx, cy + r * 1.15, cx + r * 0.75, cy + r * 0.35);
    ctx.stroke();
  } else {
    // palm
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.1, cy + r);
    ctx.quadraticCurveTo(cx + r * 0.15, cy, cx - r * 0.05, cy - r * 0.55);
    ctx.stroke();
    for (let i = 0; i < 5; i++) {
      const angle = -Math.PI * 0.85 + (Math.PI * 0.85 * i) / 2;
      ctx.beginPath();
      ctx.moveTo(cx - r * 0.05, cy - r * 0.55);
      ctx.quadraticCurveTo(
        cx - r * 0.05 + Math.cos(angle) * r * 0.6,
        cy - r * 0.55 + Math.sin(angle) * r * 0.6,
        cx - r * 0.05 + Math.cos(angle) * r * 0.95,
        cy - r * 0.55 + Math.sin(angle) * r * 0.95 + r * 0.3,
      );
      ctx.stroke();
    }
  }
  ctx.restore();
}

export default function PfpPage() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const cameraInputRef = useRef<HTMLInputElement | null>(null);
  const [scene, setScene] = useState('midnight');
  const [emblem, setEmblem] = useState('palm');
  const [handle, setHandle] = useState('');
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [photoImg, setPhotoImg] = useState<HTMLImageElement | null>(null);
  const [photoName, setPhotoName] = useState('');
  const [room, setRoom] = useState('');
  const cleanRoom = room.replace(/[^A-Za-z0-9-]/g, '').slice(0, 8).toUpperCase();
  const cleanHandle = handle.replace(/[^A-Za-z0-9_.]/g, '').slice(0, 24);

  // Load the chosen photo into an image element for canvas drawing.
  useEffect(() => {
    if (!photoUrl) {
      setPhotoImg(null);
      return;
    }
    const img = new Image();
    img.onload = () => setPhotoImg(img);
    img.src = photoUrl;
  }, [photoUrl]);

  const onPhotoChosen = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file || !file.type.startsWith('image/')) return;
    setPhotoUrl((previous) => {
      if (previous) URL.revokeObjectURL(previous);
      return URL.createObjectURL(file);
    });
    setPhotoName(file.name);
  };

  const clearPhoto = () => {
    setPhotoUrl((previous) => {
      if (previous) URL.revokeObjectURL(previous);
      return null;
    });
    setPhotoName('');
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const render = () => {
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      const size = 512;
      const palette = paletteFor(scene);
      const styles = getComputedStyle(document.documentElement);
      const backdrop = 'hsl(' + styles.getPropertyValue('--background').trim() + ')';
      const badgeFill = 'hsl(' + styles.getPropertyValue('--card').trim() + ')';
      const cx = size / 2;
      const cy = size * 0.46;
      const R = size * 0.34;
      const ringR = R + size * 0.055;
      // Backdrop behind the circular portrait
      ctx.fillStyle = backdrop;
      ctx.fillRect(0, 0, size, size);
      // Portrait clipped to a circle, X-profile-picture shaped
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.clip();
      if (photoImg && photoImg.naturalWidth > 0) {
        const ratio = Math.max(size / photoImg.naturalWidth, size / photoImg.naturalHeight);
        const w = photoImg.naturalWidth * ratio;
        const h = photoImg.naturalHeight * ratio;
        ctx.drawImage(photoImg, (size - w) / 2, (size - h) / 2, w, h);
        const shade = ctx.createLinearGradient(0, cy - R, 0, cy + R);
        shade.addColorStop(0, 'rgba(0, 0, 0, 0)');
        shade.addColorStop(1, 'rgba(0, 0, 0, 0.45)');
        ctx.fillStyle = shade;
        ctx.fillRect(0, 0, size, size);
      } else {
        const sky = ctx.createLinearGradient(0, 0, 0, size);
        sky.addColorStop(0, palette.bgTop);
        sky.addColorStop(1, palette.bgBottom);
        ctx.fillStyle = sky;
        ctx.fillRect(0, 0, size, size);
        const glow = ctx.createRadialGradient(size * 0.7, size * 0.24, 10, size * 0.7, size * 0.24, size * 0.5);
        glow.addColorStop(0, palette.glow);
        glow.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.globalAlpha = 0.55;
        ctx.fillStyle = glow;
        ctx.fillRect(0, 0, size, size);
        ctx.globalAlpha = 1;
        ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
        ctx.fillRect(0, size * 0.62, size, size * 0.38);
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
        ctx.lineWidth = 2;
        for (let i = 0; i < 4; i++) {
          const y = size * 0.68 + i * 26;
          ctx.beginPath();
          ctx.moveTo(40 + (i % 2) * 30, y);
          ctx.quadraticCurveTo(size / 2, y - 8, size - 40 - ((i + 1) % 2) * 30, y);
          ctx.stroke();
        }
      }
      ctx.restore();
      // Rim around the portrait
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
      ctx.lineWidth = 3;
      ctx.stroke();
      // Emblem sticker in the top-right corner, outside the circle so the
      // uploaded photo stays completely unobstructed
      const badgeR = size * 0.075;
      const stickerAngle = -Math.PI / 4;
      const stickerDist = ringR + badgeR + 10;
      const sx = cx + stickerDist * Math.cos(stickerAngle);
      const sy = cy + stickerDist * Math.sin(stickerAngle);
      ctx.beginPath();
      ctx.arc(sx, sy, badgeR, 0, Math.PI * 2);
      ctx.fillStyle = badgeFill;
      ctx.fill();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
      ctx.lineWidth = 2;
      ctx.stroke();
      drawEmblem(ctx, emblem, sx, sy, badgeR * 0.62, palette.ink);
      // Circular text ring: handle + bungalow number, repeated around the portrait
      const unit = '@' + (cleanHandle || 'resident') + ' · RESIDENT NUMBER ' + (cleanRoom || '???') + ' · ';
      let ring = unit;
      while (ring.length < 48) ring += unit;
      const total = ring.length;
      ctx.fillStyle = palette.ink;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.font = '500 20px "Space Grotesk", sans-serif';
      for (let i = 0; i < total; i++) {
        const angle = (i / total) * Math.PI * 2 - Math.PI / 2;
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(angle);
        ctx.fillText(ring[i], 0, -ringR);
        ctx.restore();
      }
      ctx.textBaseline = 'alphabetic';
    };
    let cancelled = false;
    document.fonts.ready.then(() => {
      if (!cancelled) render();
    });
    return () => {
      cancelled = true;
    };
  }, [scene, emblem, cleanHandle, cleanRoom, photoImg]);

  const download = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.toBlob((blob) => {
      if (!blob) return;
      const href = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = href;
      a.download = 'jb-resort-' + (cleanHandle || 'resident') + '-pfp.png';
      a.click();
      URL.revokeObjectURL(href);
    }, 'image/png');
  };

  return (
    <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={url} />
        <meta property="og:image" content={site + '/airo-assets/images/pages/home/fairy-background'} />
        <meta property="og:image:alt" content="The JB Resort fairy queen under island moonlight" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={title} />
        <meta name="twitter:description" content={description} />
        <meta name="twitter:image" content={site + '/airo-assets/images/pages/home/fairy-background'} />
        <meta name="twitter:image:alt" content="The JB Resort fairy queen under island moonlight" />
        <script type="application/ld+json">{JSON.stringify(jsonLd).replace(/</g, '\u003c')}</script>
      </Helmet>

      <main>
        {/* Hero */}
        <section className="px-base pb-xl pt-32 sm:pt-40">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUp}
            className="mx-auto w-full max-w-content"
          >
            <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-primary">{pfp.hero.eyebrow}</p>
            <h1 className="mt-lg font-heading text-5xl font-light leading-[1.05] tracking-tight text-foreground sm:text-6xl lg:text-7xl">
              {pfp.hero.title} <span className="italic">{pfp.hero.titleItalic}</span>
            </h1>
            <p className="mt-lg max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">{pfp.hero.body}</p>
          </motion.div>
        </section>

        {/* The foundry */}
        <section className="px-base pb-xl">
          <div className="mx-auto grid w-full max-w-content items-center gap-xl lg:grid-cols-[0.9fr_1.1fr] lg:gap-xxl">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
              <div className="overflow-hidden rounded-3xl border border-border shadow-xl">
                <canvas
                  ref={canvasRef}
                  width={512}
                  height={512}
                  role="img"
                  aria-label="Preview of your island resident portrait"
                  className="block aspect-square w-full"
                />
              </div>
            </motion.div>
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeUp}
              className="rounded-3xl border border-border bg-card/50 p-lg backdrop-blur-sm sm:p-xl"
            >
              <fieldset className="border-0 p-0">
                <legend className="font-mono text-[11px] uppercase tracking-[0.3em] text-primary">{pfp.labels.photo}</legend>
                <div className="mt-base flex flex-wrap items-center gap-sm">
                  <input
                    ref={fileInputRef}
                    id="pfp-photo"
                    type="file"
                    accept="image/*"
                    onChange={onPhotoChosen}
                    className="sr-only"
                  />
                  <input
                    ref={cameraInputRef}
                    id="pfp-camera"
                    type="file"
                    accept="image/*"
                    capture="environment"
                    onChange={onPhotoChosen}
                    className="sr-only"
                  />
                  <label
                    htmlFor="pfp-photo"
                    className="cursor-pointer rounded-full border px-base py-1.5 font-mono text-xs transition-colors border-primary/60 bg-primary/10 text-foreground hover:border-primary hover:text-primary"
                  >
                    {photoName ? pfp.labels.photoChange : pfp.labels.photoChoose}
                  </label>
                  <label
                    htmlFor="pfp-camera"
                    className="cursor-pointer rounded-full border px-base py-1.5 font-mono text-xs transition-colors border-primary/60 bg-primary/10 text-foreground hover:border-primary hover:text-primary"
                  >
                    {pfp.labels.cameraChoose}
                  </label>
                  {photoName ? (
                    <>
                      <span className="max-w-[16rem] truncate font-mono text-xs text-muted-foreground">{photoName}</span>
                      <button
                        type="button"
                        onClick={clearPhoto}
                        className="rounded-full border border-border px-base py-1.5 font-mono text-xs text-muted-foreground transition-colors hover:border-destructive hover:text-destructive"
                      >
                        {pfp.labels.photoRemove}
                      </button>
                    </>
                  ) : null}
                </div>
              </fieldset>
              <fieldset className="mt-xl border-0 p-0">
                <legend className="font-mono text-[11px] uppercase tracking-[0.3em] text-primary">{pfp.labels.scene}</legend>
                <div className="mt-base flex flex-wrap gap-sm">
                  {pfp.scenes.map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => setScene(s.id)}
                      aria-pressed={scene === s.id}
                      className={cn(
                        'rounded-full border px-base py-1.5 font-mono text-xs transition-colors',
                        scene === s.id
                          ? 'border-primary bg-primary text-primary-foreground'
                          : 'border-border bg-accent/40 text-muted-foreground hover:border-primary/40 hover:text-foreground',
                      )}
                    >
                      {s.name}
                    </button>
                  ))}
                </div>
              </fieldset>
              <fieldset className="mt-xl border-0 p-0">
                <legend className="font-mono text-[11px] uppercase tracking-[0.3em] text-primary">{pfp.labels.emblem}</legend>
                <div className="mt-base flex flex-wrap gap-sm">
                  {pfp.emblems.map((e) => (
                    <button
                      key={e.id}
                      type="button"
                      onClick={() => setEmblem(e.id)}
                      aria-pressed={emblem === e.id}
                      className={cn(
                        'rounded-full border px-base py-1.5 font-mono text-xs transition-colors',
                        emblem === e.id
                          ? 'border-primary bg-primary text-primary-foreground'
                          : 'border-border bg-accent/40 text-muted-foreground hover:border-primary/40 hover:text-foreground',
                      )}
                    >
                      {e.name}
                    </button>
                  ))}
                </div>
              </fieldset>
              <div className="mt-xl">
                <label htmlFor="pfp-handle" className="font-mono text-[11px] uppercase tracking-[0.3em] text-primary">
                  {pfp.labels.handle}
                </label>
                <input
                  id="pfp-handle"
                  type="text"
                  value={handle}
                  onChange={(e) => setHandle(e.target.value)}
                  placeholder="yourhandle"
                  maxLength={24}
                  className="mt-base w-full rounded-2xl border border-border bg-background/60 px-lg py-base font-mono text-sm text-foreground placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none"
                />
              </div>
              <div className="mt-xl">
                <label htmlFor="pfp-room" className="font-mono text-[11px] uppercase tracking-[0.3em] text-primary">
                  {pfp.labels.room}
                </label>
                <input
                  id="pfp-room"
                  type="text"
                  value={room}
                  onChange={(e) => setRoom(e.target.value)}
                  placeholder="001"
                  maxLength={8}
                  className="mt-base w-full rounded-2xl border border-border bg-background/60 px-lg py-base font-mono text-sm uppercase text-foreground placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none"
                />
              </div>
              <button
                type="button"
                onClick={download}
                className="group mt-xl inline-flex w-full items-center justify-center gap-3 rounded-full bg-primary px-xxl py-lg font-mono text-sm uppercase tracking-[0.2em] text-primary-foreground shadow-lg transition-transform duration-200 hover:scale-[1.02] focus-visible:outline-2 focus-visible:outline-ring sm:w-auto"
              >
                <Download aria-hidden="true" className="h-4 w-4" />
                {pfp.actions.download}
              </button>
              <p className="mt-base font-mono text-xs text-muted-foreground">{pfp.actions.note}</p>
            </motion.div>
          </div>
        </section>

        {/* Stats */}
        <section className="px-base pb-xxl">
          <div className="mx-auto w-full max-w-content">
            <ul className="flex flex-wrap justify-center gap-sm" aria-label="Portrait division at a glance">
              {pfp.stats.map((stat) => (
                <li key={stat.id}>
                  <span className="inline-block rounded-full border border-border bg-card/50 px-base py-1.5 font-mono text-xs text-foreground backdrop-blur-sm">
                    {stat.value}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </section>
      </main>
    </>
  );
}
