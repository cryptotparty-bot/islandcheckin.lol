import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import { ArrowRight, Compass } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import { cn } from '@/lib/utils';
import { map } from 'virtual:content';

interface Pin {
  handle: string;
  hood: string;
  x: number;
  y: number;
  at: string;
}

const site = 'https://islandcheckin.lol';

const title = 'Island Map — Jungle Bay Neighborhoods | JB Resort Check-In';
const description = 'Island map of Jungle Bay: Neon Lagoon, Coconut Heights, Shipwreck Shore, and The Questionable Marina — where the 1000 bungalows of the island resort sit.';
const url = site + '/map';

const jsonLd = {
  '@context': 'https://schema.org',
  '@type': 'WebPage',
  '@id': url + '#webpage',
  name: 'Island Map',
  url,
  isPartOf: { '@id': site + '/#website' },
  about: { '@id': site + '/#organization' },
};

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: 'easeOut' as const } },
} as const;

export default function MapPage() {
  const [pins, setPins] = useState<Pin[] | null>(null);

  useEffect(() => {
    let cancelled = false;
    fetch('/api/checkins')
      .then((res) => (res.ok ? res.json() : []))
      .then((rows: Pin[]) => {
        if (!cancelled) setPins(Array.isArray(rows) ? rows : []);
      })
      .catch(() => {
        if (!cancelled) setPins([]);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={url} />
        <meta property="og:image" content={site + '/airo-assets/images/pages/home/fairy-background'} />
        <meta property="og:image:alt" content="The JB Resort fairy queen under island moonlight" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={title} />
        <meta name="twitter:description" content={description} />
        <meta name="twitter:image" content={site + '/airo-assets/images/pages/map/island-map'} />
        <script type="application/ld+json">{JSON.stringify(jsonLd).replace(/</g, '\u003c')}</script>
      </Helmet>

      <main>
        {/* Hero */}
        <section className="px-base pb-xl pt-32 sm:pt-40">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUp}
            className="mx-auto w-full max-w-content"
          >
            <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-primary">{map.hero.eyebrow}</p>
            <h1 className="mt-lg font-heading text-5xl font-light leading-[1.05] tracking-tight text-foreground sm:text-6xl lg:text-7xl">
              {map.hero.title} <span className="italic">{map.hero.titleItalic}</span>
            </h1>
            <p className="mt-lg max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">{map.hero.body}</p>
          </motion.div>
        </section>

        {/* The map itself */}
        <section className="px-base pb-xl">
          <motion.figure
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUp}
            className="mx-auto w-full max-w-content overflow-hidden rounded-3xl border border-border shadow-xl"
          >
            <div className="relative">
              <img
                src="/airo-assets/images/pages/map/island-map"
                alt="Hand-drawn treasure map of a tropical island with marked landmarks and a compass rose"
                width={1200}
                height={800}
                loading="eager"
                fetchPriority="high"
                className="h-auto w-full object-cover"
              />
              {/* Checked-in resident pins, placed at the desk and stable per handle */}
              <ul aria-label="Checked-in residents" className="absolute inset-0">
                {(pins ?? []).map((pin, i) => (
                  <li
                    key={pin.handle}
                    className="absolute -translate-x-1/2 -translate-y-1/2"
                    style={{ left: pin.x + '%', top: pin.y + '%' }}
                  >
                    <a
                      href={'https://x.com/' + pin.handle}
                      target="_blank"
                      rel="noreferrer"
                      className="group flex flex-col items-center gap-1"
                      aria-label={'@' + pin.handle + ' — checked in, opens X profile in a new tab'}
                    >
                      <span className="relative flex h-4 w-4 items-center justify-center">
                        <span className="absolute h-4 w-4 animate-ping rounded-full bg-primary/50 motion-reduce:animate-none" aria-hidden="true" />
                        <span className="relative h-2.5 w-2.5 rounded-full bg-primary ring-2 ring-background shadow-lg" aria-hidden="true" />
                      </span>
                      <span
                        className={cn(
                          'whitespace-nowrap rounded-full border border-primary/50 bg-background/85 px-2 py-0.5 font-mono text-[10px] font-medium text-foreground backdrop-blur-sm transition-colors group-hover:border-primary group-hover:text-primary sm:text-[11px]',
                          i % 2 === 0 ? '-translate-y-1' : 'translate-y-4',
                        )}
                      >
                        @{pin.handle}
                      </span>
                    </a>
                  </li>
                ))}
              </ul>
              <div className="pointer-events-none absolute left-base top-base max-w-[16rem] rounded-full border border-primary/40 bg-background/80 px-base py-1 font-mono text-[10px] uppercase tracking-[0.2em] text-primary backdrop-blur-sm sm:max-w-none sm:text-[11px]">
                {map.pins.label}
                {pins !== null && pins.length > 0 ? ' · ' + pins.length + ' ' + map.pins.count : ''}
              </div>
            </div>
            <figcaption className="flex items-center justify-between gap-base bg-card/80 px-lg py-base font-mono text-xs text-muted-foreground">
              <span className="flex items-center gap-2">
                <Compass aria-hidden="true" className="h-4 w-4 text-primary" />
                Official island cartography · scale: vibes per mile
              </span>
              <span>{pins !== null && pins.length === 0 ? map.pins.empty : 'Draft 7'}</span>
            </figcaption>
          </motion.figure>
        </section>

        {/* Neighborhoods */}
        <section className="px-base py-xl">
          <div className="mx-auto grid w-full max-w-content gap-lg sm:grid-cols-2">
            {map.neighborhoods.map((hood) => (
              <motion.article
                key={hood.id}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={fadeUp}
                className="flex flex-col gap-base rounded-3xl border border-border bg-card/50 p-lg backdrop-blur-sm transition-colors hover:border-primary/40"
              >
                <div className="flex items-baseline justify-between gap-base">
                  <h2 className={cn('font-heading text-2xl font-light tracking-tight text-foreground sm:text-3xl', hood.italic && 'italic')}>
                    {hood.name}
                  </h2>
                  <span className="shrink-0 font-mono text-[11px] uppercase tracking-[0.15em] text-primary">{hood.range}</span>
                </div>
                <p className="text-base leading-relaxed text-muted-foreground">{hood.vibe}</p>
                <p className="mt-auto border-t border-border pt-base font-mono text-xs text-muted-foreground">
                  <span className="text-foreground">Landmark — </span>
                  {hood.landmark}
                </p>
              </motion.article>
            ))}
          </div>
        </section>

        {/* Legend + house rules */}
        <section className="px-base pb-xl">
          <div className="mx-auto grid w-full max-w-content gap-lg lg:grid-cols-2">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeUp}
              className="rounded-3xl border border-border bg-card/50 p-lg backdrop-blur-sm"
            >
              <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-primary">{map.legend.label}</p>
              <p className="mt-base text-lg leading-relaxed text-foreground">{map.legend.body}</p>
            </motion.div>
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeUp}
              className="rounded-3xl border border-border bg-card/50 p-lg backdrop-blur-sm"
            >
              <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-muted-foreground">{map.note.label}</p>
              <p className="mt-base text-lg leading-relaxed text-muted-foreground">{map.note.body}</p>
            </motion.div>
          </div>
        </section>

        {/* CTA */}
        <section className="px-base pb-xxl">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUp}
            className="mx-auto flex w-full max-w-content justify-center"
          >
            <Link
              to="/"
              className="group inline-flex items-center gap-3 rounded-full bg-primary px-xxl py-lg font-mono text-sm uppercase tracking-[0.2em] text-primary-foreground shadow-lg transition-transform duration-200 hover:scale-[1.03] focus-visible:outline-2 focus-visible:outline-ring"
            >
              {map.cta.text}
              <ArrowRight aria-hidden="true" className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
            </Link>
          </motion.div>
        </section>
      </main>
    </>
  );
}
