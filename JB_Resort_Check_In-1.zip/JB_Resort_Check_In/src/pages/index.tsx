import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router';
import { buildHomepageJsonLd } from '@/lib/organization-json-ld';
import { home } from 'virtual:content';

const site = 'https://islandcheckin.lol';

const title = 'JB Resort Check-In — Jungle Bay island check-in';
const description = 'Check in to Jungle Bay with your X handle, claim one of 1000 island bungalows, and receive a job title issued once and never again. For $BAYLA friends.';

const jsonLd = buildHomepageJsonLd({
  siteUrl: site,
  organizationName: 'JB Resort Check-In',
  datePublished: '2026-11-12',
  dateModified: '2026-11-12',
});

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: 'easeOut' as const } },
} as const;

interface CheckinResult {
  handle: string;
  hood: string;
  x: number;
  y: number;
}

export default function HomePage() {
  const [handle, setHandle] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [failed, setFailed] = useState(false);
  const [checkedIn, setCheckedIn] = useState<CheckinResult | null>(null);

  const onCheckIn = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (submitting) return;
    setSubmitting(true);
    setFailed(false);
    try {
      const res = await fetch('/api/checkins', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ handle }),
      });
      if (!res.ok) throw new Error('check-in rejected');
      setCheckedIn((await res.json()) as CheckinResult);
    } catch {
      setFailed(true);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={site + '/'} />
        <meta property="og:image" content={site + '/airo-assets/images/pages/home/fairy-background'} />
        <meta property="og:image:alt" content="The JB Resort fairy queen under island moonlight" />
        <meta property="og:site_name" content="JB Resort Check-In" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={title} />
        <meta name="twitter:description" content={description} />
        <meta name="twitter:image" content={site + '/airo-assets/images/pages/home/fairy-background'} />
        <meta name="twitter:image:alt" content="The JB Resort fairy queen under island moonlight" />
        <script type="application/ld+json">{JSON.stringify(jsonLd).replace(/</g, '\\u003c')}</script>
      </Helmet>

      {/* Fixed fairy-queen background, veiled for readability */}
      <div aria-hidden="true" className="pointer-events-none fixed inset-0 -z-10">
        <img
          src="/airo-assets/images/pages/home/fairy-background"
          alt=""
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-black/60" />
        <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/45 to-background/88" />
      </div>

      <main>
        {/* Hero: arrivals hall + guest identification form */}
        <section className="px-base pb-xxl pt-32 sm:pt-40">
          <div className="mx-auto grid w-full max-w-content items-center gap-xl lg:grid-cols-[1.05fr_0.95fr] lg:gap-xxl">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
              <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-primary">{home.hero.eyebrow}</p>
              <h1 className="mt-lg font-heading text-5xl font-light leading-[1.05] tracking-tight text-foreground sm:text-6xl lg:text-7xl">
                {home.hero.titleRoman} <span className="italic">{home.hero.titleItalic}</span>
              </h1>
              <p className="mt-lg max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg">{home.hero.body}</p>
            </motion.div>

            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeUp}
              className="rounded-3xl border border-border bg-card/70 p-base shadow-xl backdrop-blur-xl sm:p-lg"
            >
              <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-primary">{home.form.label}</p>
              <h2 className="mt-base font-heading text-3xl font-light text-foreground">{home.form.heading}</h2>
              {checkedIn ? (
                <div className="mt-lg rounded-xl border border-primary/40 bg-primary/10 p-lg">
                  <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-primary">{home.form.confirm}</p>
                  <p className="mt-base font-mono text-lg text-foreground">@{checkedIn.handle}</p>
                  <p className="mt-sm text-sm leading-relaxed text-muted-foreground">{home.form.confirmBody}</p>
                  <Link
                    to="/map"
                    className="mt-lg inline-flex items-center gap-2 rounded-full border border-primary/60 bg-primary/10 px-base py-1.5 font-mono text-xs text-foreground transition-colors hover:border-primary hover:text-primary"
                  >
                    {home.form.viewMap}
                    <ArrowRight aria-hidden="true" className="h-3.5 w-3.5" />
                  </Link>
                </div>
              ) : (
                <form onSubmit={onCheckIn} className="mt-lg">
                  <label htmlFor="x-handle" className="block font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                    {home.form.fieldLabel}
                  </label>
                  <div className="relative mt-sm">
                    <span aria-hidden="true" className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 font-mono text-muted-foreground">@</span>
                    <input
                      id="x-handle"
                      name="handle"
                      type="text"
                      value={handle}
                      onChange={(e) => setHandle(e.target.value)}
                      autoComplete="off"
                      autoCapitalize="none"
                      spellCheck={false}
                      placeholder={home.form.placeholder}
                      className="h-12 w-full rounded-xl border border-input bg-background/60 pl-9 pr-4 text-foreground transition-colors placeholder:text-muted-foreground/50 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/40"
                    />
                  </div>
                  <p className="mt-sm text-sm leading-relaxed text-muted-foreground">{home.form.help}</p>
                  {failed ? <p className="mt-sm font-mono text-xs text-destructive">{home.form.error}</p> : null}
                  <button
                    type="submit"
                    disabled={submitting}
                    className="mt-lg flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary font-mono text-sm font-medium uppercase tracking-[0.15em] text-primary-foreground transition-transform hover:scale-[1.01] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/60 disabled:opacity-60"
                  >
                    {submitting ? '…' : home.form.submit}
                    <ArrowRight aria-hidden="true" className="h-4 w-4" />
                  </button>
                </form>
              )}
            </motion.div>
          </div>

          <figure className="mx-auto mt-xxl w-full max-w-content">
            <div className="overflow-hidden rounded-3xl border border-border">
              <img
                src="/airo-assets/images/pages/home/hero-reception"
                alt={home.reception.alt}
                width={1424}
                height={800}
                loading="eager"
                fetchPriority="high"
                className="h-auto w-full object-cover"
              />
            </div>
          </figure>
        </section>

        {/* Occupancy ledger */}
        <section className="border-y border-border bg-card/40 px-base py-xxl">
          <div className="mx-auto grid w-full max-w-content gap-xl lg:grid-cols-2 lg:gap-xxl">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
              <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-primary">{home.ledger.label}</p>
              <p className="mt-lg font-heading text-[7rem] font-light leading-none text-foreground sm:text-[10rem] lg:text-[12rem]">{home.ledger.claimed}</p>
              <p className="mt-base max-w-sm text-lg text-muted-foreground">{home.ledger.of}</p>
              <div
                role="progressbar"
                aria-label="Bungalows claimed"
                aria-valuemin={0}
                aria-valuemax={100}
                aria-valuenow={home.ledger.percent}
                className="mt-xl h-1 w-full max-w-md overflow-hidden rounded-full bg-accent"
              >
                <motion.div
                  className="h-full min-w-2 rounded-full bg-primary"
                  initial={{ width: 0 }}
                  whileInView={{ width: home.ledger.percent + '%' }}
                  viewport={{ once: true }}
                  transition={{ duration: 1.2, ease: 'easeOut' as const }}
                />
              </div>
            </motion.div>
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
              <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-muted-foreground">{home.ledger.latestLabel}</p>
              <div className="mt-lg">
                <div className="flex flex-col gap-1 py-lg transition-colors hover:bg-accent/40 sm:flex-row sm:items-baseline sm:justify-between">
                  <a
                    href={'https://x.com/' + home.ledger.latestHandle.replace(/^@+/, '')}
                    target="_blank"
                    rel="noreferrer"
                    className="w-fit font-mono text-sm text-foreground underline-offset-4 transition-colors hover:text-primary hover:underline focus-visible:outline-2 focus-visible:outline-ring"
                    aria-label={home.ledger.latestHandle + ' on X, opens in a new tab'}
                  >
                    {home.ledger.latestHandle}
                  </a>
                  <span className="font-heading text-lg font-light italic text-muted-foreground">{home.ledger.latestJob}</span>
                </div>
                <div aria-hidden="true" className="border-t border-border" />
              </div>
            </motion.div>
          </div>
        </section>
      </main>
    </>
  );
}
