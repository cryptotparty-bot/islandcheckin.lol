import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import { ArrowRight, CupSoda, Fish, Flag, Shell } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router';
import type { LucideIcon } from 'lucide-react';
import { gifts } from 'virtual:content';

const site = 'https://islandcheckin.lol';

const ICONS: Record<string, LucideIcon> = {
  fish: Fish,
  shell: Shell,
  flag: Flag,
  cup: CupSoda,
};

interface Delivery {
  id: string;
  gift: string;
  giftName?: string;
  to: string;
  from: string | null;
  note: string | null;
  at: string;
}

export default function GiftCardPage() {
  const { giftId } = useParams<{ giftId: string }>();
  const [delivery, setDelivery] = useState<Delivery | null | 'missing'>(null);

  useEffect(() => {
    let cancelled = false;
    if (!giftId) {
      setDelivery('missing');
      return;
    }
    fetch('/api/gifts/' + encodeURIComponent(giftId))
      .then((res) => (res.ok ? res.json() : Promise.reject(new Error('missing'))))
      .then((row: Delivery) => {
        if (!cancelled) setDelivery(row);
      })
      .catch(() => {
        if (!cancelled) setDelivery('missing');
      });
    return () => {
      cancelled = true;
    };
  }, [giftId]);

  const item = delivery && delivery !== 'missing' ? gifts.items.find((entry) => entry.id === delivery.gift) : undefined;
  const cardUrl = delivery && delivery !== 'missing' ? site + '/gifts/' + delivery.id : site + '/gifts';
  const shareHref =
    delivery && delivery !== 'missing'
      ? 'https://twitter.com/intent/tweet?text=' +
        encodeURIComponent(
          'OFFICIAL NOTICE: one (1) ' +
            (delivery.giftName ?? item?.name ?? delivery.gift) +
            ', delivered by crab to @' +
            delivery.to +
            ' at JB Resort.',
        ) +
        '&url=' +
        encodeURIComponent(cardUrl)
      : '';

  return (
    <>
      <Helmet>
        <title>Delivery received — The Crab Courier | JB Resort Check-In</title>
        <meta name="description" content="An official island delivery from the Crab Courier at JB Resort on Jungle Bay. Island gifts delivered by crab, confirmed by shareable card." />
        <meta property="og:title" content="A delivery has arrived at JB Resort" />
        <meta property="og:description" content="Delivered by crab. Officially. islandcheckin.lol" />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={cardUrl} />
        <meta property="og:image" content={site + '/airo-assets/images/pages/home/fairy-background'} />
        <meta property="og:image:alt" content="The JB Resort fairy queen under island moonlight" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="A delivery has arrived at JB Resort" />
        <meta name="twitter:description" content="Delivered by crab. Officially. islandcheckin.lol" />
        <meta name="twitter:image" content={site + '/airo-assets/images/pages/home/fairy-background'} />
        <meta name="twitter:image:alt" content="The JB Resort fairy queen under island moonlight" />
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'WebPage',
            '@id': cardUrl + '#webpage',
            name: 'Island gift delivery — The Crab Courier',
            url: cardUrl,
            isPartOf: { '@id': site + '/#website' },
            about: { '@id': site + '/#organization' },
          }).replace(/</g, '\u003c')}
        </script>
      </Helmet>

      <main>
        <section className="px-base pb-xxl pt-32 sm:pt-40">
          {delivery === null ? (
            <div className="mx-auto max-w-content">
              <h1 className="font-heading text-3xl font-light text-muted-foreground sm:text-4xl">Delivery received</h1>
              <p className="mt-base font-mono text-sm text-muted-foreground">Retrieving parcel…</p>
            </div>
          ) : delivery === 'missing' ? (
            <div className="mx-auto max-w-lg rounded-3xl border border-dashed border-primary/30 bg-primary/5 p-xl text-center">
              <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-primary">{gifts.card.notFoundLabel}</p>
              <h1 className="mt-base font-heading text-2xl font-light text-foreground">{gifts.card.notFound}</h1>
              <Link
                to="/gifts"
                className="mt-lg inline-flex items-center gap-2 rounded-full border border-primary/60 bg-primary/10 px-base py-1.5 font-mono text-xs text-foreground transition-colors hover:border-primary hover:text-primary"
              >
                {gifts.card.back}
                <ArrowRight aria-hidden="true" className="h-3.5 w-3.5" />
              </Link>
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: 'easeOut' }}
              className="mx-auto w-full max-w-2xl"
            >
              <div className="rounded-3xl border-2 border-primary/50 bg-card/80 p-lg shadow-xl backdrop-blur-xl sm:p-xxl">
                <div className="flex items-center justify-between gap-base border-b border-border pb-base">
                  <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-primary sm:text-[11px]">{gifts.card.title}</p>
                  <span aria-hidden="true" className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-primary/50 bg-primary/15">
                    {(() => {
                      const Icon = ICONS[item?.icon ?? ''] ?? Fish;
                      return <Icon className="h-5 w-5 text-primary" />;
                    })()}
                  </span>
                </div>

                <p className="mt-xl font-mono text-[11px] uppercase tracking-[0.3em] text-muted-foreground">{gifts.card.for}</p>
                <h1 className="mt-sm font-heading text-5xl font-light italic tracking-tight text-foreground sm:text-6xl">
                  @{delivery.to}
                </h1>

                <p className="mt-xl font-heading text-3xl font-light text-primary sm:text-4xl">
                  1x {delivery.giftName ?? item?.name ?? delivery.gift}
                </p>
                {item ? <p className="mt-base max-w-lg text-base leading-relaxed text-muted-foreground">{item.blurb}</p> : null}

                {delivery.note ? (
                  <div className="mt-xl border-t border-border pt-lg">
                    <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">{gifts.card.noteLabel}</p>
                    <p className="mt-sm font-heading text-xl font-light italic text-foreground">&ldquo;{delivery.note}&rdquo;</p>
                  </div>
                ) : null}

                <div className="mt-xl flex flex-col gap-1 border-t border-border pt-lg font-mono text-xs text-muted-foreground sm:flex-row sm:items-baseline sm:justify-between">
                  <span>
                    {gifts.card.from} {delivery.from ? '@' + delivery.from : gifts.log.anon}
                  </span>
                  <time dateTime={delivery.at.slice(0, 10)}>
                    {new Date(delivery.at).toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' })}
                  </time>
                </div>

                <p className="mt-lg font-mono text-[11px] uppercase tracking-[0.3em] text-primary">
                  {gifts.card.by} <span className="text-foreground">{gifts.card.crab}</span>
                </p>
              </div>

              <div className="mt-lg flex flex-col gap-sm sm:flex-row">
                <a
                  href={shareHref}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-xl bg-primary px-base font-mono text-sm font-medium uppercase tracking-[0.15em] text-primary-foreground transition-transform hover:scale-[1.01] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/60"
                >
                  {gifts.card.share}
                  <ArrowRight aria-hidden="true" className="h-4 w-4" />
                </a>
                <Link
                  to="/gifts"
                  className="inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-xl border border-primary/60 bg-primary/10 px-base font-mono text-xs uppercase tracking-[0.15em] text-foreground transition-colors hover:border-primary hover:text-primary"
                >
                  {gifts.card.back}
                </Link>
              </div>
            </motion.div>
          )}
        </section>
      </main>
    </>
  );
}
