export interface SiteMeta {
	name: string;
	summary: string;
}

export const siteMeta: SiteMeta = {
	name: "JB Resort Check-In",
	summary: "A playful mock resort check-in where visitors submit an X handle to claim one of 1000 fictional bungalows and a job title that has never been issued before.",
};
