import { Helmet } from '@dr.pogodin/react-helmet';
import { type ReactElement } from 'react';
import { ScrollRestoration } from 'react-router';

import Crabs from '@/components/Crabs';
import HomepageSameAsJsonLd from '@/components/HomepageSameAsJsonLd';
import Footer from '@/layouts/parts/Footer';
import Header from '@/layouts/parts/Header';
import Website from '@/layouts/Website';

/**
 * Root layout component that wraps all pages with consistent header and footer.
 *
 * To customize the header or footer, directly edit the Header.tsx and Footer.tsx
 * files in the layouts/parts directory.
 *
 * Site-wide <title> and <meta> live in the <Helmet> below. Individual pages can
 * override them by rendering their own <Helmet> — last-mounted wins.
 */
interface RootLayoutProps {
  children: ReactElement;
}

export default function RootLayout({ children }: RootLayoutProps) {
  return (
    <Website className="bg-transparent">
      <Helmet>
        <title>JB Resort Check-In — Claim a bungalow on Jungle Bay</title>
        <meta name="description" content="The official island check-in desk of Jungle Bay: claim a bungalow, join the occupants ledger, and send island gifts by crab. For $BAYLA and Jungle Bay friends." />
        <link rel="icon" href="/assets/other/5ee66f7ed9480892dc11a31fe572197a.svg" type="image/svg+xml" />
      </Helmet>
      <HomepageSameAsJsonLd />
      <ScrollRestoration />
      <Header />
      {children}
      <Footer />
      <Crabs position="top" />
      <Crabs />
    </Website>
  );
}
