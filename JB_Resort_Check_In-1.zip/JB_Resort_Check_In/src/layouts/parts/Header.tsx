import { Link, useLocation } from 'react-router';
import { Menu, X } from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/lib/utils';

const navItems = [
  { href: '/', label: 'Desk' },
  { href: '/map', label: 'Map' },
  { href: '/residents', label: 'Occupants' },
  { href: '/pfp', label: 'PFP' },
  { href: '/gifts', label: 'Island Crab Courier' },
];

const quickLinks = [
  { href: 'https://open.spotify.com/album/7mzAJGY2Zvn10xor5JViCS', label: 'Soundtrack' },
  { href: 'https://memetics.finance', label: 'Memetics' },
  { href: 'https://memetics.wtf/bodega', label: 'Bodega' },
];

export default function Header() {
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="absolute inset-x-0 top-0 z-50">
      <div className="mx-auto flex h-20 w-full max-w-content items-center justify-between px-base">
        <Link to="/" className="group flex min-w-0 items-center gap-3" aria-label="JB Resort Check-In">
          <span aria-hidden="true" className="relative flex h-2.5 w-2.5 shrink-0">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-50" />
            <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-primary" />
          </span>
          <span className="flex min-w-0 flex-col leading-none">
            <span className="font-heading text-xl font-light tracking-tight text-foreground">JB Resort</span>
            <span className="mt-1 font-mono text-[10px] uppercase tracking-[0.35em] text-muted-foreground">Check-In</span>
          </span>
        </Link>

        <nav aria-label="Main navigation" className="hidden items-center gap-1.5 md:flex">
          {navItems.map((item) => {
            const active = location.pathname === item.href;
            return (
              <Link
                key={item.href}
                to={item.href}
                aria-current={active ? 'page' : undefined}
                className={cn(
                  'rounded-full border px-4 py-1.5 font-mono text-xs uppercase tracking-[0.15em] transition-colors',
                  active
                    ? 'border-primary bg-primary text-primary-foreground'
                    : 'border-border bg-card/60 text-muted-foreground backdrop-blur-sm hover:border-primary/40 hover:text-foreground'
                )}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="hidden items-center gap-1.5 lg:flex" aria-label="Island venues">
          {quickLinks.map((item) => (
            <a
              key={item.href}
              href={item.href}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center gap-1 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 font-mono text-xs uppercase tracking-[0.15em] text-primary transition-colors hover:bg-primary hover:text-primary-foreground"
            >
              {item.label}
              <span aria-hidden="true" className="transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5">↗</span>
            </a>
          ))}
        </div>

        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="rounded-full border border-border bg-card/60 p-2 text-foreground backdrop-blur-sm transition-colors hover:border-primary/40 md:hidden"
          aria-label="Toggle menu"
          aria-expanded={isMobileMenuOpen}
        >
          {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {isMobileMenuOpen && (
        <div className="mx-4 rounded-2xl border border-border bg-card/90 p-3 backdrop-blur-xl md:hidden">
          <nav aria-label="Mobile navigation" className="flex flex-col gap-1.5">
            {navItems.map((item) => {
              const active = location.pathname === item.href;
              return (
                <Link
                  key={item.href}
                  to={item.href}
                  aria-current={active ? 'page' : undefined}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={cn(
                    'rounded-full px-4 py-2.5 font-mono text-xs uppercase tracking-[0.15em] transition-colors',
                    active ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
                  )}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
          <div aria-hidden="true" className="my-2 border-t border-border" />
          <nav aria-label="Island venues" className="flex flex-col gap-1.5">
            {quickLinks.map((item) => (
              <a
                key={item.href}
                href={item.href}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setIsMobileMenuOpen(false)}
                className="flex items-center justify-between rounded-full px-4 py-2.5 font-mono text-xs uppercase tracking-[0.15em] text-primary transition-colors hover:bg-primary/10"
              >
                {item.label}
                <span aria-hidden="true">↗</span>
              </a>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
