import { Link } from 'react-router';

const navItems = [
  { href: '/', label: 'Desk' },
  { href: '/map', label: 'Map' },
  { href: '/residents', label: 'Occupants' },
  { href: '/pfp', label: 'PFP' },
  { href: '/gifts', label: 'Island Crab Courier' },
];

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t border-border bg-background">
      <div className="mx-auto w-full max-w-content px-base py-xxl">
        <div className="flex flex-col gap-lg md:flex-row md:items-end md:justify-between">
          <p className="max-w-md font-heading text-2xl font-light italic leading-snug text-foreground">
            Management is not responsible for crashout crabs.
          </p>
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
            For $BAYLA and Jungle Bay friends · Fun and laughter · islandcheckin.lol
          </p>
        </div>

        <div className="mt-xl flex flex-col gap-base border-t border-border pt-lg md:flex-row md:items-center md:justify-between">
          <nav aria-label="Footer links" className="flex flex-wrap gap-x-6 gap-y-2">
            {navItems.map((item) => (
              <Link
                key={item.href}
                to={item.href}
                className="font-mono text-xs uppercase tracking-[0.15em] text-muted-foreground transition-colors hover:text-primary"
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <p className="font-mono text-xs text-muted-foreground">© {currentYear} JB Resort Check-In</p>
        </div>
      </div>
    </footer>
  );
}
