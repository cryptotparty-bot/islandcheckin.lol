import { RouteObject } from 'react-router';
import { lazy } from 'react';
import HomePage from './pages/index';
import MapPage from './pages/map';
import RegistryPage from './pages/residents';
import PfpPage from './pages/pfp';
import GiftsPage from './pages/gifts';
import GiftCardPage from './pages/gift-card';
// Eager import so renderToString doesn't hit a Suspense boundary on 404 routes
// and abort to client rendering. The prod 404 page is tiny; the dev-tools
// variant stays lazy because it pulls in dev-only code we don't want in
// production bundles.
import ProdNotFoundPage from './pages/_404';

const NotFoundPage = ProdNotFoundPage;

export const routes: RouteObject[] = [
  {
    path: '/',
    element: <HomePage />,
  },
  {
    path: '/map',
    element: <MapPage />,
  },
  {
    path: '/residents',
    element: <RegistryPage />,
  },
  {
    path: '/pfp',
    element: <PfpPage />,
  },
  {
    path: '/gifts',
    element: <GiftsPage />,
  },
  {
    path: '/gifts/:giftId',
    element: <GiftCardPage />,
  },
  {
    id: 'airo-not-found',
    path: '*',
    element: <NotFoundPage />,
  },
];

// Types for type-safe navigation
export type Path = '/' | '/map' | '/residents' | '/pfp' | '/gifts' | `/gifts/${string}`;

export type Params = Record<string, string | undefined>;
